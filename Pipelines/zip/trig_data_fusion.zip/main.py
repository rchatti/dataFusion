import requests
import os

def py_entry(event, context):
    print(event)